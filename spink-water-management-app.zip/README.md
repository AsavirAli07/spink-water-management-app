# Spink Water Management App 🚰

This is a simple Flutter app for water management.

## How to Run

```bash
flutter pub get
flutter run
```

## GitHub Actions

This repo is pre-configured with a workflow to:
- Install Flutter
- Build APKs (debug + release)
- Upload them as artifacts
